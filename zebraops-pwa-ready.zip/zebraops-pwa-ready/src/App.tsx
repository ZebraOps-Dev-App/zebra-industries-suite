
function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 text-gray-900">
      <h1 className="text-4xl font-bold">🚀 ZebraOps PWA is Live!</h1>
    </div>
  );
}

export default App;
