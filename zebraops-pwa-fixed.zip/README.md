# ZebraOps PWA

A starter PWA for inventory automation, built with Vite + React + Supabase.