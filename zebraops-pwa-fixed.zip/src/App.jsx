import React from 'react'
export default function App() {
  return <div className='text-2xl font-bold text-center p-10'>Welcome to ZebraOps</div>
}