import React from 'react';

const App = () => {
  return (
    <div className="p-10">
      <h1 className="text-4xl font-serif text-gold">Welcome to ZebraOps</h1>
      <p className="text-white/70">Luxury Monogram UI is live.</p>
    </div>
  );
};

export default App;