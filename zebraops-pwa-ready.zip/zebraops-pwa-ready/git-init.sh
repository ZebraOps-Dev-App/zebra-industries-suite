
#!/bin/bash
git init
git remote add origin https://github.com/YOUR_USERNAME/zebraops-pwa.git
git add .
git commit -m "Initial commit"
git push -u origin main
